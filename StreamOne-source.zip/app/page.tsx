"use client";

import { useState } from "react";

const navItems = [
  { icon: "⌂", label: "直播工作台" },
  { icon: "◈", label: "今晚方案" },
  { icon: "◎", label: "实时场控" },
  { icon: "⚔", label: "PK 对手库" },
  { icon: "♫", label: "才艺内容库" },
  { icon: "▥", label: "直播复盘" },
];

const schedule = [
  { time: "20:00", title: "暖场聊天", note: "聊聊今天的小确幸", tone: "mint" },
  { time: "20:18", title: "点歌互动", note: "《小幸运》+ 弹幕点歌", tone: "violet" },
  { time: "20:38", title: "连麦 PK", note: "@橘子汽水｜轻松聊天局", tone: "orange" },
  { time: "20:55", title: "舞蹈时间", note: "Jazz 串烧 · 8分钟", tone: "pink" },
];

export default function Home() {
  const [active, setActive] = useState("直播工作台");

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">S</span>
          <div><strong>StreamOne</strong><small>直播运营助手</small></div>
        </div>
        <nav aria-label="主导航">
          {navItems.map((item) => (
            <button key={item.label} className={active === item.label ? "nav-item active" : "nav-item"} onClick={() => setActive(item.label)}>
              <span className="nav-icon">{item.icon}</span>{item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-tip">
          <span className="tip-kicker">AI 场控提示</span>
          <strong>直播前准备完成度</strong>
          <div className="progress"><i /></div>
          <small>已完成 8 / 10 项</small>
        </div>
        <div className="profile-row">
          <div className="avatar">梨</div>
          <div><strong>小梨同学</strong><small>娱乐主播 · 晚八点档</small></div>
          <span>•••</span>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">MONDAY · 8月17日</p>
            <h1>晚上好，小梨 <span>✦</span></h1>
            <p>今晚的直播作战卡已经准备好了。</p>
          </div>
          <div className="top-actions">
            <button className="icon-button" aria-label="消息">◌<b /></button>
            <button className="primary-button">▶&nbsp;&nbsp;进入场控模式</button>
          </div>
        </header>

        <div className="hero-grid">
          <article className="live-card">
            <div className="live-card-head"><div><span className="status-dot" />今晚 20:00 开播</div><button>编辑方案</button></div>
            <div className="live-card-main">
              <div><span className="pill">今晚主题</span><h2>夏日心动电台</h2><p>轻松聊天 · 唱歌 · 好友PK · Jazz串烧</p></div>
              <div className="countdown"><small>距离开播</small><strong>03:42:18</strong></div>
            </div>
            <div className="goal-row">
              <span>本场目标</span>
              <div><b>+120</b><small>新增关注</small></div><div><b>18 min</b><small>平均停留</small></div><div><b>8.5%</b><small>互动率</small></div>
            </div>
          </article>
          <article className="ai-card">
            <div className="ai-orb">✦</div><span className="pill dark">AI 今日建议</span>
            <h3>把第一首歌提前 8 分钟</h3><p>最近三场数据显示，20:15 左右进入才艺环节，平均停留提升 12%。</p>
            <button>应用到流程 <span>→</span></button>
          </article>
        </div>

        <section className="content-grid">
          <article className="panel run-sheet">
            <div className="panel-head"><div><h3>今晚直播流程</h3><p>预计 90 分钟 · 4 个核心环节</p></div><button className="text-button">查看完整方案&nbsp; →</button></div>
            <div className="schedule">
              {schedule.map((item, index) => (
                <div className="schedule-item" key={item.time}>
                  <time>{item.time}</time><span className={`timeline-dot ${item.tone}`}>{index + 1}</span>
                  <div><strong>{item.title}</strong><small>{item.note}</small></div>{index === 1 && <em>AI 推荐</em>}<button aria-label={`打开${item.title}`}>›</button>
                </div>
              ))}
            </div>
          </article>
          <aside className="right-column">
            <article className="panel readiness">
              <div className="panel-head"><div><h3>开播准备</h3><p>还有 2 项待完成</p></div><span>80%</span></div>
              <div className="ready-progress"><i /></div>
              <label><input type="checkbox" defaultChecked /> 灯光与收音测试</label><label><input type="checkbox" defaultChecked /> 伴奏和舞蹈音乐</label>
              <label><input type="checkbox" /> 确认 PK 对手在线</label><label><input type="checkbox" /> 发布开播预告</label>
            </article>
            <article className="risk-card"><div className="risk-icon">!</div><div><span>今晚风险提醒</span><strong>PK 环节避免涉及私人联系方式和消费承诺。</strong></div><button aria-label="查看风险详情">›</button></article>
          </aside>
        </section>
      </section>
    </main>
  );
}
