import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(new Request("http://localhost/"));
}

test("serves the StreamOne entertainment live-operations app", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>StreamOne · 娱乐直播运营助手<\/title>/);
  assert.match(html, />歌曲\s*<b>24<\/b>/);
  assert.match(html, />舞蹈\s*<b>8<\/b>/);
  assert.match(html, />聊天话题\s*<b>36<\/b>/);
  assert.match(html, /Jazz 夏日串烧/);
  assert.match(html, /最近一次被陌生人治愈/);
  assert.match(html, /评价其他主播收入或流水/);
  assert.doesNotMatch(html, /MuseCast/);
});

test("builds a self-contained StreamOne HTML deliverable", async () => {
  const html = await readFile(
    new URL("../outputs/StreamOne.html", import.meta.url),
    "utf8",
  );

  assert.match(html, /<style>[\s\S]+<\/style>/);
  assert.match(html, /<script>[\s\S]+<\/script>/);
  assert.match(html, /StreamOne/);
  assert.match(html, /libraryData/);
  assert.doesNotMatch(html, /<link[^>]+rel=["']stylesheet["']/i);
  assert.doesNotMatch(html, /MuseCast/);
});
