# StreamOne

StreamOne 是面向娱乐主播的 PC 端直播运营助手，适用于 PK、聊天、唱歌和跳舞类直播场景。

## 当前功能

- 今日直播作战台：目标、流程、数据和风险提醒
- AI 直播助手：开场、转场、PK、留人和冷场话术
- 节目单：按直播阶段安排歌曲、舞蹈和互动内容
- 才艺内容库：歌曲、舞蹈与聊天话题的表现数据和风险分级
- 复盘分析：直播数据、关键时刻和后续优化建议

## 直接预览

打开 `outputs/StreamOne.html` 即可使用完整的单文件 PC 页面，无需安装依赖。

## 本地开发

需要 Node.js 22.13 或更高版本。

```bash
npm install
npm run dev
```

## 构建与测试

```bash
npm run build
npm test
```

构建完成后会生成：

- `outputs/StreamOne.html`：可直接打开的单文件页面
- `dist/server/index.js`：Cloudflare 兼容的服务端产物

## 品牌

产品名称统一为 **StreamOne**。
